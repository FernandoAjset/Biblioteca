/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author Fernando Ajset
 */

/*
Si vacio
    inicio= Nuevo(y)
    nuevo.sig=Iniciio
    Inicio=Nuevo
Fin Si

*/
public class Lista {
     protected Nodo Inicio;
     
     Lista()
     {
         Inicio=null;
     }        
     public void IngresarInicio(int pDato)
     {
         if(Inicio==null)
         {
             Inicio= new Nodo(pDato);
         }
         else
         {
             Nodo nuevo = new Nodo(pDato);
             nuevo.setSig(Inicio);
             Inicio=nuevo;
         }
     }
     
     /*  PSEUDOCODIGO PARA RECORRER
        aux=inicio;
        Mientras (aux!=nulo) entonces
            imprimir(aux.dato)
            aux=aux.sig;
        Fin Mientras
     */
     public void Recorrer()
     {
         Nodo aux=Inicio;
         System.out.println("Recorrer Lista: ");
         while(aux!=null)
         {
             System.out.println("Dato: "+aux.DarDato());
             aux=aux.DarSig();
         }
     }
     
     public String DarLista()
     {
         String lista = new String();
         Nodo aux=Inicio;
         while(aux!=null)
         {
             //System.out.println(aux.DarDato());
             
             lista+=String.valueOf(aux.DarDato())+" , ";
             aux=aux.DarSig();
         }
         return lista;
     }
     
     public boolean Existe(int pdato)
     {
         boolean respuesta=false;
         Nodo aux=Inicio;
         System.out.println("Buscar en Lista: ");
         while(aux!=null)
         {
             if (pdato==aux.DarDato())
             {
             respuesta=true;
             }
             aux=aux.DarSig();
         }
         return respuesta;
     }
     
     public static void main(String args[])
     {
         Lista l1 = new Lista();
         Lista l2 = new Lista();
         
         l1.IngresarInicio(3);
         l1.IngresarInicio(2);
         l1.IngresarInicio(1);
         
         l2.IngresarInicio(7);
         l2.IngresarInicio(8);
         l2.IngresarInicio(9);
        
         l1.Recorrer();
         l2.Recorrer();
         int x=2;
         
         if(l1.Existe(x)==true)
         {    
            System.out.println("El numero "+x+" si está en la lista");
         }
         else
         {
             System.out.println("No se encontró el numero en la lista");
         }
         
     }
}
