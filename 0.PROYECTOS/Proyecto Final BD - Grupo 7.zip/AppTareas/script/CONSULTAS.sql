select * from tarea;

--***Usuario con m�s tareas asignadas**--
--vista para traer cantidad de tareas por usuario
CREATE OR REPLACE VIEW MAXIMO AS
SELECT ID_USUARIO, COUNT(*) TAREAS
FROM TAREA
WHERE ESTADO=0
GROUP BY ID_USUARIO
ORDER BY COUNT(*) DESC;

--consulta usando vista para traer el maximo
SELECT u.id_usuario, u.nombre, m.tareas
FROM MAXIMO M
LEFT JOIN USUARIOS U
ON u.id_usuario=m.id_usuario
where m.tareas=(SELECT MAX(m2.tareas) FROM maximo m2);






--consulta para mostrar tareas por departamento
SELECT t.id_tarea, t.descripcion, u.usuario
FROM TAREA T
LEFT JOIN USUARIOS U
ON T.id_usuario=U.id_usuario
LEFT JOIN departamento d
ON u.id_departamento=d.id_departamento
WHERE d.nombred='INFRAESTRUCTURA';


SELECT u.nombre, a.tareas
FROM ATRASADAS A
LEFT JOIN USUARIOS U
ON u.id_usuario=a.id_usuario
where 
 u.id_departamento=3 and a.tareas=(SELECT max(a2.tareas) from atrasadas a2 where id);


SELECT u.id_usuario, a2.tareas
FROM atrasadas a2
LEFT JOIN usuarios u
on u.id_usuario=a2.id_usuario0
where u.id_departamento=3
;


--consulta para mostrar usuario con mas tareas atrasadas
CREATE OR REPLACE VIEW ATRASADAS AS
SELECT ID_USUARIO, COUNT(*) TAREAS
FROM TAREA
WHERE SYSDATE -FECHAASIGNACION >=15 AND ESTADO=0
GROUP BY ID_USUARIO
ORDER BY COUNT(*) DESC;

SELECT u.id_usuario, u.nombre, MAX(m.tareas) FROM MAXIMO M LEFT JOIN USUARIOS U ON u.id_usuario=m.id_usuario;
SELECT id_usuario, COUNT(tareas)from MAXIMO where tareas=max(tareas);

SELECT * from maximo;

--consulta usando fechas atrasadas usando el maximo
SELECT u.id_usuario, u.nombre, A.tareas
FROM atrasadas A
LEFT JOIN USUARIOS U
ON u.id_usuario=A.id_usuario
where A.tareas=(SELECT MAX(A2.tareas) FROM ATRASADAS A2);
SELECT *FROM ATRASADAS;

--tareas asignadas por dia ultimos 5 dias
--funcion 
CREATE OR REPLACE FUNCTION tareafecha(idUsuario NUMBER, dias NUMBER)RETURN NUMBER IS
vTareas number;
BEGIN
SELECT count(id_tarea) tareas into vTareas from tarea where id_usuario=idUsuario and sysdate-fechaasignacion>dias and sysdate-fechaasignacion<dias+1
group by id_usuario, fechaasignacion;
return vTareas;
END;

--VISTA PARA TRAER TODOS
CREATE OR REPLACE VIEW ultimosCincoDias AS
SELECT t.id_usuario,u.usuario,d.id_departamento,
nvl(tareafecha(t.id_usuario,1),0) HACE_1_DIAS, 
nvl(tareafecha(t.id_usuario,2),0) HACE_2_DIAS, 
nvl(tareafecha(t.id_usuario,3),0) HACE_3_DIAS,
nvl(tareafecha(t.id_usuario,4),0) HACE_4_DIAS,
nvl(tareafecha(t.id_usuario,5),0) HACE_5_DIAS
FROM tarea t
LEFT JOIN usuarios u
ON t.id_usuario=u.id_usuario
LEFT JOIN departamento d
ON u.id_departamento=d.id_departamento
GROUP BY t.id_usuario,u.usuario,d.id_departamento
order by t.id_usuario ASC;

--Consulta para usuario tipo 1
SELECT * FROM ULTIMOSCINCODIAS;

--Consulta para usuario tipo 2
SELECT * FROM ULTIMOSCINCODIAS WHERE ID_DEPARTAMENTO=2;

--Consulta para usuario tipo 3
SELECT * FROM ULTIMOSCINCODIAS WHERE ID_USUARIO=6;


---	Matriz mostrando el n�mero de actividades finalizadas por mes. (�ltimos 3 meses)
--Funcion para traer tareas finalizadas por mes
CREATE OR REPLACE FUNCTION tareasmes(idUsuario NUMBER, mes NUMBER)RETURN NUMBER IS
vTareas number;
BEGIN
SELECT COUNT(*) tareas INTO vTareas FROM tarea WHERE id_usuario=idUsuario and ESTADO=1 AND EXTRACT(MONTH FROM fechafinalizacion)=EXTRACT(MONTH FROM sysdate)-mes
group by id_usuario;
return vTareas;
END;

--Vista para traer los 3 meses
CREATE OR REPLACE VIEW tareaUltimosMeses AS
SELECT t.id_usuario,u.usuario,d.id_departamento,
nvl(TAREASMES(t.id_usuario,1),0) HACE_1_MES,
nvl(TAREASMES(t.id_usuario,2),0) HACE_2_MESES,
nvl(TAREASMES(t.id_usuario,3),0) HACE_3_MESES
FROM tarea t
LEFT JOIN usuarios u
ON t.id_usuario=u.id_usuario
LEFT JOIN departamento d
ON u.id_departamento=d.id_departamento
GROUP BY t.id_usuario,u.usuario,d.id_departamento
order by t.id_usuario ASC;

--Consulta para usuario tipo 1
SELECT * FROM TAREAULTIMOSMESES;

--Consulta para usuario tipo 2
SELECT * FROM TAREAULTIMOSMESES WHERE id_departamento=2;

--Consulta para usuario tipo 3
SELECT * FROM TAREAULTIMOSMESES WHERE id_usuario=8;


