create or replace TRIGGER TRG_NUEVA_TAREA
BEFORE INSERT ON TAREA
FOR EACH ROW
DECLARE 
  idBitacora number;
  idTarea number; 
BEGIN
    SELECT NVL(MAX(ID_BITACORA),0)+1 into idBitacora from bitacora; 
    SELECT NVL(MAX(ID_TAREA),0)+1 into idTarea from tarea;
    INSERT INTO BITACORA VALUES(idBitacora,SYSDATE,'Tarea creada con ID: '||idTarea);
END TRG_NUEVA_TAREA;
/

create or replace TRIGGER TRG_REASIGNAR_TAREA
BEFORE UPDATE OF ID_USUARIO
ON TAREA
FOR EACH ROW
DECLARE 
  idBitacora number;
BEGIN
SELECT NVL(MAX(ID_BITACORA),0)+1 into idBitacora from bitacora; 
INSERT INTO BITACORA VALUES(idBitacora,SYSDATE,'Tarea reasignada usuario anterior: '||:old.id_usuario||' , usuario nuevo: '||:new.id_usuario);
END TRG_REASIGNAR_TAREA;
/


create or replace TRIGGER TRG_TERMINAR_TAREA
BEFORE UPDATE OF ESTADO
ON TAREA
FOR EACH ROW
DECLARE 
  idBitacora number;
BEGIN
SELECT NVL(MAX(ID_BITACORA),0)+1 into idBitacora from bitacora; 
INSERT INTO BITACORA VALUES(idBitacora,SYSDATE,'Tarea terminada, ID TAREA: '||:new.id_tarea);
END TRG_REASIGNAR_TAREA;
/