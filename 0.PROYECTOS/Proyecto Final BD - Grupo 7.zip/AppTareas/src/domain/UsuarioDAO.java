package domain;

import conexiones.Conexion;
import static conexiones.Conexion.getConnection;
import java.sql.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ferajset
 */
public class UsuarioDAO {

    private Connection conexion;

    public UsuarioDAO() {

    }

    public UsuarioDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean seleccionar(Usuario user) throws SQLException {
        boolean r = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet res = null;
        try {
            conn = this.conexion != null ? this.conexion : Conexion.getConnection();
            String SQL_SELECT = "SELECT u.id_usuario, u.usuario, u.contraseña, u.id_tipo, u.id_departamento, tu.nombre_tipo "
                    + "FROM usuarios u LEFT JOIN Tipo_de_usuario tu ON u.id_tipo=tu.id_tipo";
            stmt = conn.prepareStatement(SQL_SELECT);
            res = stmt.executeQuery();
            while (res.next()) {
                String usuario = res.getString("usuario");
                String password = res.getString("contraseña");
                if (user.getUsuario().equalsIgnoreCase(usuario)) {
                    if (user.getContraseña().equals(password)) {
                        user.setId_usuario(res.getInt("id_usuario"));
                        user.setId_tipo(res.getInt("id_tipo"));
                        user.setNombre_tipo(res.getString("nombre_tipo"));
                        user.setId_departamento(res.getInt("id_departamento"));
                        r = true;
                    }
                }
            }
        } finally {
            try {
                Conexion.close(res);
                Conexion.close(stmt);
                if (this.conexion == null) {
                    Conexion.close(conn);
                    conn.close();
                    //this.conexion.close();
                    //System.out.println("cerrado: " + conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return r;
    }

    public void verTareas(int id_departamento, DefaultTableModel modelo) throws SQLException {
        Connection conn = null;
        ResultSet res = null;
        PreparedStatement stmt = null;
        String SQL_SELECT = "SELECT t.id_tarea, t.descripcion, u.usuario FROM tarea t LEFT JOIN usuarios u ON t.id_usuario=u.id_usuario where estado=0 AND id_departamento='" + id_departamento + "'";
        try {
            conn = this.conexion != null ? this.conexion : Conexion.getConnection();
            modelo.setRowCount(0);

            stmt = conn.prepareStatement(SQL_SELECT);
            res = stmt.executeQuery();
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getInt(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                modelo.addRow(v);
            }
        } catch (Exception ex) {
            System.out.println("Falla al cargar usuarios");
            ex.printStackTrace();
        } finally {
            try {
                Conexion.close(res);
                Conexion.close(stmt);
                Conexion.close(conn);
                conn.close();
                this.conexion.close();
                //System.out.println("cerrado: " + conn);               
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    public String verUsuarios(int id_tipo, int id_departamento, int id_usuario) {
        String respuesta = new String();
        switch (id_tipo) {
            case 1:
                respuesta = "SELECT id_usuario, nombre, usuario, puesto from Usuarios";
                break;
            case 2:
                respuesta = "SELECT id_usuario, nombre, usuario, puesto, id_departamento from Usuarios where id_departamento='" + id_departamento + "'";
                break;

            case 3:
                respuesta = "SELECT id_usuario, nombre, usuario, puesto, id_departamento from Usuarios where id_usuario='" + id_usuario + "'";
                break;
        }

        return respuesta;
    }

    public static int verIdMax() {
        int id = 0;
        Connection conn = null;
        ResultSet res = null;
        PreparedStatement stmt = null;
        String SQL_SELECT = "SELECT NVL(MAX(ID_TAREA),0)+1 FROM TAREA";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            res = stmt.executeQuery();

            while (res.next()) {
                id = res.getInt(1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                Conexion.close(res);
                Conexion.close(stmt);
                Conexion.close(conn);
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return id;
    }

    public boolean asignarTarea(String desc, int id) {
        boolean r = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String SQL_INSERT = "INSERT INTO tarea(id_tarea, descripcion, estado, id_usuario)VALUES(?,?,?,?)";
        int registros = 0;
        int idNuevo = verIdMax();
        //System.out.println("idNuevo = " + idNuevo);
        try {
            conn = this.conexion != null ? this.conexion : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setInt(1, idNuevo);
            stmt.setString(2, desc);
            stmt.setInt(3, 0);
            stmt.setInt(4, id);
            registros = stmt.executeUpdate();
            r = true;
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                Conexion.close(conn);
                conn.close();
                this.conexion.close();
                //System.out.println("cerrado: " + conn);               
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return r;
    }

    public boolean reAsigarTarea(int idTarea, int idUsuario) {
        boolean r = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String SQL_UPDATE = "UPDATE tarea SET id_usuario=? WHERE id_tarea='" + idTarea + "'";
        try {
            conn = this.conexion != null ? this.conexion : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, idUsuario);
            stmt.executeUpdate();
            r = true;
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                Conexion.close(conn);
                conn.close();
                this.conexion.close();
                //System.out.println("cerrado: " + conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return r;
    }

    public boolean terminarTarea(int idTarea) {
        boolean r = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String SQL_UPDATE = "UPDATE tarea SET fechafinalizacion=sysdate, estado=? WHERE ROWNUM=1 AND id_tarea='" + idTarea + "'";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, 1);
            stmt.executeUpdate();
            r = true;
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                Conexion.close(conn);
                conn.close();
                //System.out.println("cerrado: " + conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return r;
    }

}
