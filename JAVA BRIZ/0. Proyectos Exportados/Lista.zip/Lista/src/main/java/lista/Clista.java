/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
si vacio
    inicio=nuevo
sino
nuevo=nuevo(x)
nuevo siguiente=inicio
inicio =nuevo
fin si.
*/

package lista;


import lista.Nodo;


public class Clista {
    //atributos
  protected Nodo Inicio;  
  
  //metodos
 //constructor
  Clista(){
      Inicio=null;
  }
  
  public void IngresarInicio (int pDato){
     if (Inicio==null){
         Inicio=new Nodo(pDato);
     }
     
     else {
         Nodo nuevo = new Nodo(pDato);
         nuevo.setSig(  Inicio);
         Inicio=nuevo;
     }
  }

  public void Recorrer (){
      
    Nodo aux = Inicio;
    System.out.println("Contenido Lista");
    while(aux!=null){
        System.out.println(aux.DarDato());
        aux=aux.DarSig();
    }
  }
  
  public boolean Existe(int pdato)
     {
         boolean r=false;
         Nodo aux=Inicio;
         
         
         System.out.println("\nBuscando numero en Lista: ");
         while(aux!=null)
         {
             if (pdato==aux.DarDato())
             {
             r=true;
             }
             aux=aux.DarSig();
         }
         return r;
     }
  
  public String DarLista()
  {
      String lista = new String();
      Nodo aux=Inicio;
      while(aux!=null)
      {
          lista+=String.valueOf(aux.DarDato())+"  ";
             aux=aux.DarSig();
      }
      return lista;
  }
  
  public static void main (String args[]){
      Clista l1 = new Clista();
      l1.IngresarInicio(3);
      l1.IngresarInicio(2);
      l1.IngresarInicio(1);
      l1.Recorrer();
      
      //VARIABLE QUE CONTIENE DATO A BUSCAR
         int x=3;
         
         if(l1.Existe(x)==true)
         {    
            System.out.println("El "+x+" se encuentra en la lista");
         }
         else
         {
             System.out.println("Numero no se encontró");
         }
      
  }
}


