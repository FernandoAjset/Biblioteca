/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Brizeth Alvarado
 */
public class funciones {
    public int m[][]=new int[3][3];
    
    public static String turno(String t){
        //String Respuesta=new String();
        if(t=="x")
            t="O";
            return t;

    }
    public void ingreso(int m[][]){
        
    }
}


